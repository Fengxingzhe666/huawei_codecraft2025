﻿// 磁盘写入分区设想.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <random>
#include <unordered_map>
#include <vector>
#include "DISK.hpp"

using std::unordered_map;
using std::vector;

// 这里定义了一些与题目规模或常量有关的宏
#define MAX_DISK_NUM (10 + 1)          // 最大硬盘数(示例中预留10个+1)
#define MAX_DISK_SIZE (16384 + 1)      // 每块硬盘最大存储单元数量(示例中预留16384+1)
#define MAX_REQUEST_NUM (30000000 + 1) // 最大读请求数量
#define MAX_OBJECT_NUM (100000 + 1)    // 最大对象数量
#define REP_NUM (3)                    // 冗余副本数量(要求3份)
#define FRE_PER_SLICING (1800)         // 时间片相关(示例中只演示，不深入使用)
#define EXTRA_TIME (105)               // 额外的时间片数量

// 请求结构体，用于保存某次读请求的信息
typedef struct Request_ {
    int object_id;  // 需要读取的对象ID
    int prev_id;    // 链表式指向上一个请求的ID(用于回溯)
    bool is_done;   // 该请求是否已完成
} Request;

// 对象结构体，用于保存对象信息
typedef struct Object_ {
    int replica[REP_NUM];          // 记录对象的三个副本在哪些硬盘上
    int* unit[REP_NUM];            // 每个副本对应的存储单元编号数组
    int size;                      // 对象大小(单位: 对象块数)
    int tag;                       // 新增：对象的tag
    int last_request_point;        // 记录最后一次发起读请求的编号(用于回溯、取消等)
    bool is_delete;                // 标记该对象是否已被删除
} Object;


int T, M, N, V, G;
//int disk[MAX_DISK_NUM][MAX_DISK_SIZE]; // 模拟硬盘，disk[i][j]存储对象ID

vector<DISK> disk;                       //N块硬盘，每块硬盘由V个存储单元构成
int disk_point[MAX_DISK_NUM];            // 如果需要按顺序分配存储单元，可以在此记录下一个可分配位置
// 全局数组
Request request[MAX_REQUEST_NUM];
Object object[MAX_OBJECT_NUM];           //注意对象数组object的索引在这个规则里从1开始

// 输出当前时间片，并读取(丢弃)判题器给的"TIMESTAMP"
void timestamp_action()
{
    int timestamp;
    // 读入格式："TIMESTAMP X"
    // %*s表示跳过一个字符串(即"TIMESTAMP")，读入后面的X
    scanf("%*s%d", &timestamp);
    // 按照题目规则，原样输出"TIMESTAMP X"
    printf("TIMESTAMP %d\n", timestamp);

    fflush(stdout);
}

/*
* n_write：代表这一时间片写入对象的个数。 输入数据保证总写入次数小于等于100000。
* 接下来 n_write 行，每行三个数 obj_id[i]、 obj_size[i]、 obj_tag[i]，代表当前时间片写入的对象编
号， 对象大小，对象标签编号。
* 输入数据保证 obj_id 为1开始每次递增1的整数， 且1 ≤ 𝑜𝑏𝑗_𝑠𝑖𝑧𝑒[𝑖] ≤ 5，1 ≤ 𝑜𝑏𝑗_𝑡𝑎𝑔[𝑖] ≤ 𝑀
*/
// 写入动作处理函数
void write_action()
{
    int n_write;
    // 读取本时间片要写入的对象数量
    scanf("%d", &n_write);
    // 对每个要写入的对象依次处理
    for (int i = 1; i <= n_write; i++) {
        int id, size, tag;
        // 读入对象id、大小，tag
        scanf("%d%d%d", &id, &size, &tag);
        // 初始化该对象的last_request_point等信息
        object[id].last_request_point = 0;
        for (int j = 0; j < REP_NUM; j++) {
            //当前为第j个副本;
            // 副本放到 j % N 的硬盘上(演示用)
            object[id].replica[j] = j % N;
            // 为对象的第 j 副本分配一个int数组，用于记录写在哪些存储单元
            object[id].unit[j] = static_cast<int*>(malloc(sizeof(int) * (size + 1)));
            object[id].size = size;
            object[id].is_delete = false;
            object[id].tag = tag;
            size_t disk_idx = object[id].replica[j];
            //对每个size都要进行一次写入
            for (size_t k = 0;k < size;k++) {
                object[id].unit[j][k] = disk[disk_idx].writein(tag);
            }
        }

        /*
        * 输出包含4 ∗ 𝑛_𝑤𝑟𝑖𝑡𝑒行，每4行代表一个对象：
        * 第一行一个整数 obj_id[i]，表示该对象的对象编号。
        * 接下来一行，第一个整数 rep[1]表示该对象的第一个副本写入的硬盘编号，接下来对象大小(obj_size)个整数 unit[1][j]，代表第一个副本第𝑗个对象块写入的存储单元编号。
        * 第三行，第四行格式与第二行相同，为写入第二，第三个副本的结果。
        */
        printf("%d\n", id);
        for (int j = 0; j < REP_NUM; j++) {
            //这里范围从1开始变为c++索引从0开始，需要+1
            printf("%d", object[id].replica[j] + 1);
            for (int k = 0; k < size; k++) {
                printf(" %d", object[id].unit[j][k] + 1);
            }
            printf("\n");
        }
    }
    fflush(stdout);
}

// 删除动作处理函数
void delete_action()
{
    int n_delete;
    int abort_num = 0; // 需要被取消的读请求计数
    static int _id[MAX_OBJECT_NUM];

    // 读入本时间片删除的对象数量n_delete
    scanf("%d", &n_delete);
    // 依次读入要删除的对象id
    for (int i = 1; i <= n_delete; i++) {
        scanf("%d", &_id[i]);
    }

    // 统计所有要删除对象所关联的未完成读请求(后续需要输出并取消)
    for (int i = 1; i <= n_delete; i++) {
        int id = _id[i];
        int current_id = object[id].last_request_point;
        // 回溯该对象最近所有读请求，如果存在 is_done == false，就要被取消
        while (current_id != 0) {
            if (request[current_id].is_done == false) {
                abort_num++;
            }
            current_id = request[current_id].prev_id;
        }
    }

    // 输出总的取消请求数量
    printf("%d\n", abort_num);

    // 逐个对象输出需要取消的请求编号，并真正删除硬盘上的数据
    for (int i = 1; i <= n_delete; i++) {
        int id = _id[i];
        int current_id = object[id].last_request_point;
        // 输出所有未完成的读请求编号
        while (current_id != 0) {
            if (request[current_id].is_done == false) {
                printf("%d\n", current_id);
            }
            current_id = request[current_id].prev_id;
        }
        // 真正删除对应硬盘上的内容，这里范围从1开始变为c++索引从0开始
        for (int j = 0; j < REP_NUM; j++) {
            /*do_object_delete(object[id].unit[j],
                disk[object[id].replica[j]],
                object[id].size);*/

                //_id[]表示要删除的id数组，object[id]表示本次循环要删除的object对象，要删除的是其第j个副本，disk_idx是对应硬盘索引，disk_unit是对应存储单元索引
            int disk_idx = object[id].replica[j];
            //对每个block进行一次删除
            for (int k = 0;k < object[id].size;k++) {
                int disk_unit = object[id].unit[j][k];
                disk[disk_idx].delete_act(disk_unit);
            }

        }
        // 标记该对象已删除
        object[id].is_delete = true;
    }
    fflush(stdout);
}

/*
* n_read：代表这一时间片读取对象的个数。 输入数据保证总读取次数小于等于30000000。
* 接下来 n_read 行，每行两个数 req_id[i]、 obj_id[i]，代表当前时间片读取的请求编号和请求的对象
编号。 输入数据保证读请求编号为 1 开始每次递增 1 的整数， 读取的对象在请求到来的时刻一定在存储系
统中。
*/
// 读取动作处理函数
void read_action()
{
    int n_read;
    int request_id, object_id;
    // 本时间片有多少个读请求
    scanf("%d", &n_read);

    // 读取所有读请求，并串成“单向链表”，方便回溯
    for (int i = 1; i <= n_read; i++) {
        scanf("%d%d", &request_id, &object_id);
        // 记录该读请求对应的对象、上一个请求ID
        request[request_id].object_id = object_id;
        request[request_id].prev_id = object[object_id].last_request_point;
        // 将该请求链到对象的末尾
        object[object_id].last_request_point = request_id;
        // 刚到来的请求标记未完成
        request[request_id].is_done = false;
    }

    // 用于演示的静态变量，表示“当前正在处理的请求”和“读到第几步”
    static int current_request = 0;
    static int current_phase = 0;

    // 如果当前没有正在处理的请求，而且本时间片新来了读请求，就先把最新那个设置为“当前请求”
    if (!current_request && n_read > 0) {
        current_request = request_id;
    }

    // 每个时间片需要输出N行磁头动作，然后再输出一个数字(上报完成请求数量)
    if (!current_request) {
        // 如果当前没有要处理的请求，则所有磁头都无动作
        for (int i = 0; i < N; i++) {
            printf("#\n");
        }
        // 无请求完成
        printf("0\n");
    }
    else {
        // 有正在进行的请求
        current_phase++;
        object_id = request[current_request].object_id;
        // 输出N行磁头动作(示例演示：只有副本1的硬盘会做一点读或跳过)
        // ps：硬盘的索引从0开始
        for (int i = 0; i < N; i++) {
            // 如果这是该对象第一份副本所在的硬盘
            if (i == object[object_id].replica[0]) {
                // 演示：奇数phase时做一次“j(ump)/read”的切换，偶数phase时输出"r#"或类似
                if (current_phase % 2 == 1) {
                    // 假装在奇数phase时，用“j x”动作
                    // 注意unit索引从0开始
                    printf("j %d\n", object[object_id].unit[0][current_phase / 2] + 1);
                }
                else {
                    // 偶数phase时，输出"r#"让磁头读
                    printf("r#\n");
                }
            }
            else {
                // 其他硬盘无动作
                printf("#\n");
            }
        }

        // 如果phase达到对象大小 * 2，就说明已将该对象的全部块“读取”完
        if (current_phase == object[object_id].size * 2) {
            // 如果对象已被删除，就上报0(表示没有请求完成)
            if (object[object_id].is_delete) {
                printf("0\n");
            }
            else {
                // 否则上报1个请求完成，并输出该请求编号
                printf("1\n%d\n", current_request);
                // 标记此请求已完成
                request[current_request].is_done = true;
            }
            // 重置
            current_request = 0;
            current_phase = 0;
        }
        else {
            // 否则本时间片不上报任何完成
            printf("0\n");
        }
    }

    fflush(stdout);
}


int main()
{
    // 读入T, M, N, V, G
    scanf("%d%d%d%d%d", &T, &M, &N, &V, &G);

    // 此处根据赛题输入格式，示例中直接跳过一些输入(3 * M行，每行ceil(T/1800)个数)
    for (int i = 1; i <= M; i++) {
        for (int j = 1; j <= (T - 1) / FRE_PER_SLICING + 1; j++) {
            scanf("%*d");
        }
    }
    for (int i = 1; i <= M; i++) {
        for (int j = 1; j <= (T - 1) / FRE_PER_SLICING + 1; j++) {
            scanf("%*d");
        }
    }
    for (int i = 1; i <= M; i++) {
        for (int j = 1; j <= (T - 1) / FRE_PER_SLICING + 1; j++) {
            scanf("%*d");
        }
    }
    disk = vector<DISK>(N, DISK(V, M));           //N块硬盘，每块硬盘由V个存储单元构成
    // 输出"OK"表示预处理阶段完成
    printf("OK\n");
    fflush(stdout);


    // 主循环：从时间片1到T + EXTRA_TIME
    for (int t = 1; t <= T + EXTRA_TIME; t++) {
        timestamp_action(); // 1. 时间片对齐
        delete_action();    // 2. 删除操作
        write_action();     // 3. 写入操作
        read_action();      // 4. 读取操作
    }
    return 0;
}
